export default {
  allowedFileSize: 'Unggah file dengan ukuran maks. {maxSize}.',
  allowedFileValidatorSimple: 'Unggah file {allowedType} dengan ukuran maks. {maxSize}.',
  allowedFileValidatorComplex:
    'Unggah file {allowedTypesArray}, atau {allowedTypesLastItem} dengan ukuran maks. {maxSize}.',
  dragAndDropText: 'Seret & Jatuhkan file di sini atau', // TODO: or what? Why is Drag & Drop capitalized?
  fileNameDescriptionLabel: 'Nama file: ',
  generalValidatorMessage: '"{validatorMessage}", untuk {listOfErroneousFiles}.',
  noFilesSelected: 'Tidak ada file yang dipilih.',
  noFilesUploaded: 'Tidak ada file yang diunggah.',
  fileSelected: 'File yang dipilih: ',
  fileUploaded: 'File yang diunggah: ',
  filesSelected: 'File yang dipilih: {numberOfFiles} file.',
  filesUploaded: 'File yang diunggah: {numberOfFiles} file.',
  removeButtonLabel: 'Hapus file {fileName}',
  selectTextDuplicateFileName: 'File dengan nama file yang sama sudah ada.',
  selectTextMultipleFile: 'Pilih beberapa file',
  selectTextSingleFile: 'Pilih berkas',
};
