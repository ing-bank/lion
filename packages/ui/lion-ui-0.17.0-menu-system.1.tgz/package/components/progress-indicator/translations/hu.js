export default {
  loading: 'Betöltés',
};
