export default {
  loading: 'Načítání',
};
