export default {
  loading: 'Зареждане',
};
