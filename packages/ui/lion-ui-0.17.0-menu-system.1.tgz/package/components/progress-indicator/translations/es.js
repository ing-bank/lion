export default {
  loading: 'Cargando',
};
