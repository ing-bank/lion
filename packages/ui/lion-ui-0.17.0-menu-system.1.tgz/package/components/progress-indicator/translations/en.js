export default {
  loading: 'Loading',
};
