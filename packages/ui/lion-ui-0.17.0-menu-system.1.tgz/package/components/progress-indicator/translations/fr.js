export default {
  loading: 'Chargement',
};
